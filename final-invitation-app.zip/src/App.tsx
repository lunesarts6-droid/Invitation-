
import { useRef, useState } from 'react'

export default function App() {
  const cardRef = useRef<HTMLDivElement>(null)
  const [bg, setBg] = useState('#fffaf3')
  const [font, setFont] = useState('Georgia')
  const [name, setName] = useState('Sarah & Ahmed')
  const [date, setDate] = useState('12 • 08 • 2026')

  const download = () => {
    if (!cardRef.current) return
    import('html-to-image').then(({ toPng }) => {
      toPng(cardRef.current!).then(dataUrl => {
        const link = document.createElement('a')
        link.download = 'invitation.png'
        link.href = dataUrl
        link.click()
      })
    })
  }

  return (
    <>
      <div className="controls">
        <label>Background </label>
        <input type="color" value={bg} onChange={e => setBg(e.target.value)} />
        <label> Font </label>
        <select onChange={e => setFont(e.target.value)}>
          <option>Georgia</option>
          <option>Playfair Display</option>
          <option>Times New Roman</option>
        </select>
        <button onClick={download}>Download</button>
      </div>

      <div className="card" ref={cardRef} style={{ background: bg, fontFamily: font }}>
        <h1>Welcome To Our Wedding</h1>
        <h2 contentEditable suppressContentEditableWarning onBlur={e => setName(e.currentTarget.textContent || '')}>
          {name}
        </h2>
        <p>{date}</p>
      </div>
    </>
  )
}
